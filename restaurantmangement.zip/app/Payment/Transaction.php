<?php

namespace App\Payment;

use Illuminate\Database\Eloquent\Model;

class Transaction extends Model
{
    //
}

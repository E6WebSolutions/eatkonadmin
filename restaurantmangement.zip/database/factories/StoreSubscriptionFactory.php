<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\StoreSubscription;
use Faker\Generator as Faker;

$factory->define(StoreSubscription::class, function (Faker $faker) {
    return [
        //
    ];
});

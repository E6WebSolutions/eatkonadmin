<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\OrderItemAddon;
use Faker\Generator as Faker;

$factory->define(OrderItemAddon::class, function (Faker $faker) {
    return [
        //
    ];
});

<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\StoreSlider;
use Faker\Generator as Faker;

$factory->define(StoreSlider::class, function (Faker $faker) {
    return [
        //
    ];
});

<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\AddonCategoryItem;
use Faker\Generator as Faker;

$factory->define(AddonCategoryItem::class, function (Faker $faker) {
    return [
        //
    ];
});

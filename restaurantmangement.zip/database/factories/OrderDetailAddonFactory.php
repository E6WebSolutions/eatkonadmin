<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\OrderDetailAddon;
use Faker\Generator as Faker;

$factory->define(OrderDetailAddon::class, function (Faker $faker) {
    return [
        //
    ];
});

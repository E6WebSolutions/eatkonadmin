<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\OderDetails;
use Faker\Generator as Faker;

$factory->define(OderDetails::class, function (Faker $faker) {
    return [
        //
    ];
});
